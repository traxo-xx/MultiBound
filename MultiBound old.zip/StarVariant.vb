﻿Public Class StarVariant
    Public Property Value As Object
    Public Property Type As VariantTypes

End Class
Public Enum VariantTypes
    _Null = 1
    _Double = 2
    _Boolean = 3
    _VLQ = 4
    _String = 5
    _VariantArray = 6
    _Dictionary = 7
End Enum
